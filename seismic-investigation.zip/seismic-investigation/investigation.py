"""Research exercise: out-of-window tests of seismic reflectivity regularization.
Independent implementation of Yang et al. (2025), Eq. 4, not authors' software.
Commands are explicit stages; calibration never reads evaluation reflectivity.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('MPLCONFIGDIR',str(__import__('pathlib').Path(__file__).resolve().parent/'.plot-cache'))
from pathlib import Path
import argparse,hashlib,io,json,time
import numpy as np
import pandas as pd
from scipy.signal import hilbert,find_peaks
from scipy.linalg import eigh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':12,'figure.facecolor':'#f3f1e9','axes.facecolor':'#f3f1e9','axes.spines.top':False,'axes.spines.right':False})
DT=.002;N=151;CORE=slice(25,-25);FREQ=40.;DELTA=.5
C={'L2':'#a75632','L1':'#296780','Mixed':'#7a508d'}

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def savej(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False))
def inputs():
 p=ROOT/'data';s=(p/'F02-1_logs.las').read_text();a=np.loadtxt(io.StringIO(s.split('~A',1)[1].split('\n',1)[1]));valid=(a[:,1]>0)&(a[:,2]>0);a=a[valid];z=a[:,1]*1e6/a[:,2]
 td=np.loadtxt(p/'F02-1_TD.txt');ts=np.interp(a[:,0],td[:,1],td[:,0])/1000
 return a,z,ts

def truth(which):
 _,z,t=inputs();start={'development':.6,'evaluation':1.1}[which];tt=start+np.arange(N)*DT;zz=np.interp(tt,t,z);r=np.r_[0,np.diff(zz)/(zz[1:]+zz[:-1])]
 return tt,r

def operator(phase=0.,frequency=FREQ):
 tt=(np.arange(N)-N//2)*DT;q=np.pi*frequency*tt;w=(1-2*q*q)*np.exp(-q*q);w=np.cos(np.deg2rad(phase))*w-np.sin(np.deg2rad(phase))*np.imag(hilbert(w));w/=np.linalg.norm(w)
 ij=np.arange(N)[:,None]-np.arange(N)[None,:]+N//2;G=np.where((ij>=0)&(ij<N),w[np.clip(ij,0,N-1)],0.)
 return G,w

def solve(G,data,l1,l2,delta=DELTA,maxiter=20000):
 # Objective exactly ||Gr-d||² + l1||r||1 + l2(delta||r||²+(1-delta)||Dr||²).
 # FISTA gradient has factor 2; threshold is l1/L. L >= Hessian spectral radius.
 D=np.diff(np.eye(N),axis=0);H=2*(G.T@G+l2*(delta*np.eye(N)+(1-delta)*D.T@D));B=2*G.T@data
 L=float(eigh(H,subset_by_index=[N-1,N-1],eigvals_only=True)[0]);x=np.zeros_like(B);y=x.copy();mom=1.
 for it in range(maxiter):
  u=y-(H@y-B)/L;new=np.sign(u)*np.maximum(np.abs(u)-l1/L,0);m2=(1+np.sqrt(1+4*mom*mom))/2;y=new+(mom-1)/m2*(new-x);x=new;mom=m2
  if it%50==0:
   grad=H@x-B;res=np.where(np.abs(x)>1e-9,np.abs(grad+l1*np.sign(x)),np.maximum(np.abs(grad)-l1,0));kkt=float(np.max(res));scale=max(float(np.max(np.abs(B))),1e-10)
   if kkt/scale<1e-7:break
 return x,{'iterations':it+1,'relative_kkt':kkt/scale,'converged':kkt/scale<1e-7}

def noisy(r,phase,snr_db,seeds):
 G,_=operator(phase);clean=G@r;sd=np.sqrt(np.mean(clean[CORE]**2))*10**(-snr_db/20)
 return np.column_stack([clean+np.random.default_rng(int(s)).normal(0,sd,N) for s in seeds]),clean,sd

def score(r,x,threshold):
 # Error uses the central 202 ms only, avoiding window-edge artifacts.
 a=r[CORE];b=x[CORE];weak=(np.abs(a)>1e-12)&(np.abs(a)<=threshold);nre=float(np.sum((a-b)**2)/np.sum(a*a));wnre=float(np.sum((a[weak]-b[weak])**2)/np.sum(a[weak]**2))
 return nre,wnre

def audit():
 manifest=json.loads((ROOT/'manifest.json').read_text());checks=[]
 for item in manifest['files']:
  p=ROOT/item['path'];assert digest(p)==item['sha256'],p;checks.append({'file':item['path'],'bytes':p.stat().st_size,'verified':True})
 pd.DataFrame(checks).to_csv(OUT/'source-checks.csv',index=False)
 a,z,ts=inputs();td,rd=truth('development');te,re=truth('evaluation');section=np.loadtxt(ROOT/'data/export_inline362.ascii');tt=np.arange(section.shape[1]-2)*.004
 fig,ax=plt.subplots(1,3,figsize=(15,5),layout='constrained');v=np.percentile(abs(section[:,2:]),98);ax[0].imshow(section[:,2:].T,extent=[section[0,1],section[-1,1],tt[-1],0],aspect='auto',cmap='RdBu_r',vmin=-v,vmax=v);ax[0].set(ylim=(1.5,.4),xlabel='Crossline index',ylabel='Two-way time (s)',title='F3 observed filtered section')
 ax[1].plot(z/1e6,ts,color='#296780');ax[1].axhspan(.6,.9,color='#69aaa0',alpha=.3,label='Development');ax[1].axhspan(1.1,1.4,color='#ae86b5',alpha=.3,label='Evaluation');ax[1].set(ylim=(1.5,.4),xlabel='Impedance (million kg m⁻² s⁻¹)',ylabel='Provided time-depth model (s)',title='Real F02-1 density and sonic logs');ax[1].legend()
 ax[2].plot(td,rd,color='#296780');ax[2].set(xlabel='Time (s)',ylabel='Reflection coefficient',title='Development reflectivity only');fig.savefig(OUT/'01-evidence.png',dpi=150);plt.close(fig)
 pd.DataFrame({'depth_m':a[:,0],'density_kg_m3':a[:,1],'sonic_us_m':a[:,2],'velocity_m_s':1e6/a[:,2]}).to_csv(OUT/'log-audit.csv',index=False)
 print(pd.DataFrame(checks).to_string(index=False));print('LAS units: RHOB kg/m3; DT microseconds/m. NULL=-999.25. Valid positive-density/slowness rows:',len(a));print('Development 0.60–0.90 s; evaluation 1.10–1.40 s; 200 ms gap. Inversion samples every 2 ms. Real seismic is context, not ground-truth evaluation. Wavelet and phase below are assumed, not measured from this field section.')

def calibrate():
 if (OUT/'frozen-settings.json').exists():raise FileExistsError('Calibration already frozen. Preserve it; use a new project for a new study.')
 _,r=truth('development');G,_=operator();seeds=[11,12,13,14];d,_,_=noisy(r,0,20,seeds);threshold=float(np.median(np.abs(r[CORE][np.abs(r[CORE])>1e-12])));smax=float(np.max(np.abs(2*G.T@d.mean(axis=1))));gscale=float(np.linalg.norm(G,2)**2)
 params={'L1':[(f*smax,0.) for f in [.003,.01,.03,.1]],'L2':[(0.,f*gscale) for f in [.001,.01,.1,1.]],'Mixed':[(f*smax,g*gscale) for f in [.003,.01,.03,.1] for g in [.001,.01,.1]]}
 rows=[];chosen={}
 for method,values in params.items():
  for l1,l2 in values:
   x,qc=solve(G,d,l1,l2);assert qc['converged'],qc;ss=[score(r,x[:,j],threshold) for j in range(len(seeds))];rows.append(dict(method=method,l1=l1,l2=l2,nre=np.mean([x[0] for x in ss]),weak_nre=np.mean([x[1] for x in ss]),**qc))
  win=min([x for x in rows if x['method']==method],key=lambda x:x['nre']);chosen[method]={'l1':win['l1'],'l2':win['l2']}
 df=pd.DataFrame(rows);df.to_csv(OUT/'development-grid.csv',index=False)
 settings={'objective':'squared residual + l1*L1(r) + l2*(0.5*L2(r)^2+0.5*L2(Dr)^2)','paper':'https://doi.org/10.1038/s41598-025-25543-x','implementation':'Independent FISTA solver for Eq.4; not author code or a reproduction of their field results','assumed_frequency_hz':FREQ,'assumed_phase_deg':0,'development_snr_db':20,'development_seeds':seeds,'weak_threshold':threshold,'chosen':chosen,'selection':'minimum mean full-reflectivity NRE on development only; mixed has 12 settings, baselines 4 each','primary_test':'paired NRE and weak-coefficient NRE against L1 and L2, both reported; no guaranteed winner','script_sha256':digest(Path(__file__))}
 savej(OUT/'frozen-settings.json',settings)
 fig,ax=plt.subplots(figsize=(12,5),layout='constrained')
 for method in params:
  z=df[df.method==method];ax.scatter(range(len(z)),z.nre,label=method,color=C[method],s=65)
 ax.set(xlabel='Candidate setting within each method',ylabel='Development mean normalized squared error',title='Select settings on development; freeze before evaluation');ax.legend();fig.savefig(OUT/'02-calibration.png',dpi=150);plt.close(fig)
 print(pd.DataFrame([min([x for x in rows if x['method']==m],key=lambda x:x['nre']) for m in params]).to_string(index=False));print('Settings frozen using development NRE only. Evaluation has not been run.')

def evaluate(label,phase=0.,snr=20.,seed_start=100):
 if not label.replace('-','').isalnum():raise ValueError('Use alphanumeric label')
 dest=OUT/label;dest.mkdir(exist_ok=False);cfg=json.loads((OUT/'frozen-settings.json').read_text());assert cfg['script_sha256']==digest(Path(__file__));tt,r=truth('evaluation');seeds=list(range(seed_start,seed_start+24));assert not set(seeds)&set(cfg['development_seeds']);data,clean,noise_sd=noisy(r,phase,snr,seeds);G,w=operator(0);rows=[];estimates={};threshold=cfg['weak_threshold'];peak_cut=2*threshold
 before={'label':label,'true_phase_deg':phase,'assumed_phase_deg':0,'snr_db':snr,'seeds':seeds,'evaluation_scope':'same held-out log interval, noise realizations; not independent wells','calibration_sha256':digest(OUT/'frozen-settings.json'),'status':'running'};savej(dest/'run-record.json',before)
 for method,params in cfg['chosen'].items():
  x,qc=solve(G,data,**params);assert qc['converged'],qc;estimates[method]=x
  for j,seed in enumerate(seeds):
   nre,wnre=score(r,x[:,j],threshold);truth_peaks=find_peaks(np.abs(r[CORE]),height=peak_cut,distance=2)[0];pred=find_peaks(np.abs(x[CORE,j]),height=peak_cut,distance=2)[0];left=list(truth_peaks);matched=0
   for pk in pred:
    if left and min(abs(np.array(left)-pk))<=1:idx=int(np.argmin(abs(np.array(left)-pk)));left.pop(idx);matched+=1
   rows.append(dict(method=method,seed=seed,nre=nre,weak_nre=wnre,trace_misfit=float(np.mean((G@x[:,j]-data[:,j])**2)/noise_sd**2),true_peaks=len(truth_peaks),reported_peaks=len(pred),matched_peaks=matched,false_peaks=len(pred)-matched,missed_peaks=len(left),**qc))
 df=pd.DataFrame(rows);df.to_csv(dest/'metrics.csv',index=False);summary=df.groupby('method')[['nre','weak_nre','false_peaks','missed_peaks','trace_misfit']].median();summary.to_csv(dest/'summary.csv');paired=[]
 for baseline in ['L1','L2']:
  for metric in ['nre','weak_nre']:
   b=df[df.method==baseline].set_index('seed')[metric];m=df[df.method=='Mixed'].set_index('seed')[metric];delta=(b-m).to_numpy();paired.append(dict(baseline=baseline,metric=metric,median_baseline_minus_mixed=float(np.median(delta)),noise_q05=float(np.quantile(delta,.05)),noise_q95=float(np.quantile(delta,.95)),mixed_wins=int(np.sum(delta>0)),replicates=len(delta)))
 pd.DataFrame(paired).to_csv(dest/'paired-comparison.csv',index=False)
 fig,ax=plt.subplots(2,2,figsize=(15,9),layout='constrained');ax[0,0].plot(tt,data[:,0],color='#58636c',label='Observed synthetic');ax[0,0].plot(tt,clean,'k--',label='Noise-free forward trace');ax[0,0].set(title=f'Withheld log interval · true phase {phase:g}° · SNR {snr:g} dB',xlabel='Time (s)',ylabel='Amplitude');ax[0,0].legend()
 ax[0,1].plot(tt[CORE],r[CORE],color='black',lw=2,label='Log-derived truth')
 for method,x in estimates.items():ax[0,1].plot(tt[CORE],x[CORE,0],color=C[method],label=method,lw=1.3)
 ax[0,1].set(title='Reflectivity recovery · first fixed noise realization',xlabel='Time (s)',ylabel='Reflection coefficient');ax[0,1].legend(ncol=2)
 for k,metric in enumerate(['nre','weak_nre']):
  axis=ax[1,k]
  for i,method in enumerate(C):
   vals=df[df.method==method][metric];axis.scatter(np.full(len(vals),i)+np.linspace(-.12,.12,len(vals)),vals,s=20,color=C[method],alpha=.6);axis.plot([i-.2,i+.2],[vals.median()]*2,color=C[method],lw=4)
  axis.axhline(1,color='#777777',ls=':',label='Zero-reflectivity reference');axis.legend(fontsize=9);axis.set(xticks=range(3),xticklabels=list(C),ylabel='Normalized squared error · lower is better',title='All reflectivity' if metric=='nre' else 'Weak coefficients · threshold frozen on development')
 fig.suptitle('Frozen settings · identical evaluation data for all methods',fontsize=19);fig.savefig(dest/'03-evaluation.png',dpi=140);plt.close(fig)
 pd.DataFrame({'time_s':tt,'truth':r,'observed_first':data[:,0],**{k:v[:,0] for k,v in estimates.items()}}).to_csv(dest/'first-trace.csv',index=False)
 before.update(status='completed',note='5–95% ranges describe noise-realization variation, not population confidence. Peak tolerance ±2 ms; threshold 2× development weak threshold.');savej(dest/'run-record.json',before);print(summary.to_string());print(pd.DataFrame(paired).to_string(index=False));print(before['note'])

def verify_solver():
 from scipy.optimize import minimize
 rng=np.random.default_rng(9);G,_=operator();d=rng.normal(size=(N,1));l2=.3;l1=0.;x,q=solve(G,d,l1,l2);D=np.diff(np.eye(N),axis=0);direct=np.linalg.solve(G.T@G+l2*(.5*np.eye(N)+.5*D.T@D),G.T@d);assert np.allclose(x,direct,atol=1e-5)
 # Check nonsmooth objective against independent bound-constrained positive/negative split.
 l1=.1;x,q=solve(G,d,l1,l2);H=G.T@G+l2*(.5*np.eye(N)+.5*D.T@D);b=G.T@d[:,0]
 def fun(uv):
  r=uv[:N]-uv[N:];g=2*(H@r-b);return float(r@H@r-2*b@r+l1*np.sum(uv)),np.r_[g+l1,-g+l1]
 opt=minimize(fun,np.zeros(2*N),jac=True,bounds=[(0,None)]*(2*N),method='L-BFGS-B',options={'maxiter':3000,'ftol':1e-13,'gtol':1e-8});rel=abs(fun(np.r_[np.maximum(x[:,0],0),np.maximum(-x[:,0],0)])[0]-opt.fun)/max(abs(opt.fun),1e-12);assert rel<1e-6,(opt.message,rel);print('Independent solver checks passed:',q,'relative objective difference',rel)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('stage',choices=['audit','calibrate','evaluate','verify']);p.add_argument('--label',default='evaluation');p.add_argument('--phase',type=float,default=0);p.add_argument('--snr',type=float,default=20);p.add_argument('--seed-start',type=int,default=100);a=p.parse_args();start=time.perf_counter()
 if a.stage=='audit':audit()
 elif a.stage=='calibrate':calibrate()
 elif a.stage=='evaluate':evaluate(a.label,a.phase,a.snr,a.seed_start)
 else:verify_solver()
 print(f'Execution time: {time.perf_counter()-start:.2f} s')
